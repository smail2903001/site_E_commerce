-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 25 avr. 2022 à 23:23
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `shopee`
--

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `item_id` int(11) NOT NULL,
  `item_brand` varchar(200) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `item_register` datetime DEFAULT NULL,
  `item_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`item_id`, `item_brand`, `item_name`, `item_price`, `item_image`, `item_register`, `item_description`) VALUES
(1, 'Histoire', ' Les villes impériales', 152.00, './assets/products/1.png', '2020-03-28 11:08:57', 'Ces romans, contes et récits, nés de la confrontation du rêve et de la réalité nous permettent de découvrir \"l\'Empire fortuné\" du Maroc, à la fois si proche et si lointain.\r\nIl existe, selon Pierre Loti, pionnier parmi les écrivains voyageurs au Maroc, \"plusieurs manières de décrire les pays... Il y a d\'abord les articles très sérieux : études approfondies, détails comme en peuvent fournir les gens qui ont vécu très longtemps dans les endroits dont ils parlent. Puis il y a les notes rapides qui sont comme les impressions sténographiées du voyageur qui passe\". Il y a enfin, aurait-il pu ajouter,\r\nles récits de fiction nés de la confrontation du rêve et de la réalité.'),
(2, 'Histoire', 'Histoire du Maroc - Des origines à nos jours', 144.00, './assets/products/2.jpg', '2020-03-28 11:08:57', 'En 987, quand Hugues Capet monte sur le trône de France, l\'Etat marocain a déjà deux siècles d\'existence. \r\nA la différence de tout ce qui avait été écrit jusque-là, Bernard Lugan replace dans ce livre le Maroc au coeur de l\'espace saharo-méditerranéen. \r\nVers l\'est, sous les Almoravides (XIe-XIIe siècles) et plus encore sous les Almohades (XIIe-XIIIe siècles), \r\nle Maroc domina territorialement tout le Maghreb.'),
(3, 'Histoire', 'La mémoire d\'un roi', 177.00, './assets/products/3.jpg', '2020-03-28 11:08:57', 'Ce livre est un document exceptionnel. Hassan II, roi du Maroc depuis trente-deux ans, a accepté de répondre à toutes les questions d\'Eric Laurent, \r\nn\'esquivant aucun sujet, même les plus délicats ou les plus brulants. Jamais le souverain marocain n\'était allé aussi loin dans les confidences, \r\nqu\'il s\'agisse de sa vie, du métier de roi, de ses rapports avec la France ou de ses relations avec de Gaulle, Mitterrand, Giscard d\'Estaing, Pompidou. \r\nA la fois acteur et conteur de l\'histoire, mêlant anecdotes, réflexions et révélations, il entraine les lecteurs dans ses parties d\'échecs avec Boumedienne, \r\nses affrontements puis ses réconciliations avec Kadhafi. Il évoque ses discussions avec Kissinger et Bush, \r\nses rencontres secrètes avec Moshe Dayan puis Itzhak Rabin. Pour la première fois, il ouvre un certain nombre de dossiers et, au fil des pages, \r\nl\'homme se révèle derrière le monarque. Il livre sa vision du pouvoir, explique ses choix pour le Maroc, sans éluder les drames qui ont marque son règne, \r\nqu\'il s\'agisse d\'Oufkir ou de Ben Barka. A la fois proche de la France et méconnu chez nous, suscitant des passions, Hassan II, à travers ce témoignage historique, \r\nnous fournit les clés d\'une histoire hors du commun dont il est l\'acteur essentiel.'),
(5, 'Islamique', 'Le résumé des oeuvres de la \'Umra et du Hadj ', 122.00, './assets/products/5.png', '2020-03-28 11:08:57', '\r\nUn bon résumé des oeuvres de la \'Umra et du Hadj afin d\'accomplir le 5ème pilier de l\'Islam conformément à la Sounnah de notre Noble Prophète \r\n-salla ALLAH \'aleyhi a sallam-.'),
(8, 'Islamique', 'La Confiance en Allah', 89.00, './assets/products/8.jpg', '2020-03-28 11:08:57', 'Si tu as admis qu’Allah Seul agit, et que tu crois que Sa Science, Sa Puissance et Sa Miséricorde sont parfaites, que tu es convaincu qu’il n’existe aucune puissance, science ou compassion au-delà des Siennes, alors inévitablement ton cœur s’en remettra totalement à Lui Seul. Dans ce cas, jamais tu ne porteras pas ton attention sur un autre que Lui.'),
(9, 'Islamique', '100 trésors de l\'Islam', 129.00, './assets/products/9.jpg', '2020-03-28 11:08:57', 'Quel que soit le stade où vous en êtes dans votre vie, il est fort probable que vous souhaitiez l\'améliorer.\r\n\r\nPour vous aider à y parvenir, ce livre énumère 100 principes tirés du Coran et de la Sunna.'),
(10, 'Islamique', 'Conseils du Prophète', 149.00, './assets/products/10.jpg', '2020-03-28 11:08:57', 'Ibn ‘Abbas a dit :\r\n\r\n« Un jour où je me trouvais derrière le Prophète (sur lui la paix et le salut), il me dit : « Ô jeune homme ! Vais-je t’enseigner quelques paroles par lesquelles Allah te permettra de tirer profit ? ».\r\n\r\nJe répondis : « Bien sûr ! ».\r\n\r\nIl dit : « Préserve Allah et Il te préservera. Préserve Allah et tu Le trouveras devant toi. Connais Allah dans la facilité et Il te connaîtra dans la difficulté. Lorsque tu demandes, demande à Allah. Lorsque tu sollicites de l’aide, sollicite celle d’Allah. La plume est levée et les pages ont séché. Si toutes les créatures se réunissaient pour essayer de t’apporter un bienfait à travers une chose qu’Allah n’a pas ordonnée, elles ne pourraient pas y parvenir. Et si elles se liguaient pour te nuire, à travers une chose qu’Allah n’a pas décrétée, elles ne pourraient pas y parvenir. Sache qu’une bien immense repose dans le fait de supporter patiemment ce que tu détestes, que la victoire vient avec la patience, que le soulagement vient après la détresse et que la facilité vient après la difficulté. ».');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'aminekouis@gmail.com', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'),
(2, 'aaa', 'aaaaa@gmail.com', 'ed02457b5c41d964dbd2f2a609d63fe1bb7528dbe55e1abf5b52c249cd735797'),
(3, 'bb', 'bb@gmail.com', '3b64db95cb55c763391c707108489ae18b4112d783300de38e033b4c98c3deaf'),
(7, 'teeest', 'teest@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(9, 'ouhni', 'ouhni.m2015@gmail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
(10, 'a', 'ouhni.fst@uhp.ac.ma', '15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225'),
(11, 'Elmehdi ', 'elkari@gmail.com', 'e8706d8424b7e75be7513786c1e70e1a2e1773ad4b76b0edcbef2ed7795d7093'),
(14, 'anaaa', 'ana@gmail.com', '8e9b468cbb72b7b3141d14bd14bc2ed3ef9b9365af3a727285d5adf8faa51234');

-- --------------------------------------------------------

--
-- Structure de la table `wishlist`
--

CREATE TABLE `wishlist` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `wishlist`
--

INSERT INTO `wishlist` (`cart_id`, `user_id`, `item_id`) VALUES
(18, 1, 2),
(14, 1, 1),
(15, 1, 9),
(16, 1, 5);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`item_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `c1` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
